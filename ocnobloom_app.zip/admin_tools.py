﻿"""
admin_tools.py
----------------------------------------
Admin Management Utility for Data Vault

Functions:
  1ï¸âƒ£ make_admin(email)     â†’ Promote user to admin
  2ï¸âƒ£ list_admins()         â†’ List all current admins
  3ï¸âƒ£ remove_admin(email)   â†’ Revoke admin rights from a user

Usage:
  Run this file in your terminal using:
      python admin_tools.py
----------------------------------------
"""

import sqlite3
import os

DB_NAME = "data_entry.db"  # Must match your app.py file

# --------------------------
# Utility Functions
# --------------------------
def connect_db():
    if not os.path.exists(DB_NAME):
        print(f"âŒ Database '{DB_NAME}' not found in this directory.")
        return None
    return sqlite3.connect(DB_NAME)

# --------------------------
# 1ï¸âƒ£ Promote a User to Admin
# --------------------------
def make_admin(email):
    conn = connect_db()
    if not conn:
        return
    cur = conn.cursor()

    cur.execute("SELECT id, username, is_admin FROM users WHERE email = ?", (email,))
    user = cur.fetchone()

    if not user:
        print(f"âš ï¸ No user found with email: {email}")
    elif user[2] == 1:
        print(f"âœ… '{email}' is already an admin.")
    else:
        cur.execute("UPDATE users SET is_admin = 1 WHERE email = ?", (email,))
        conn.commit()
        print(f"ðŸ‘‘ '{email}' has been promoted to admin successfully!")

    conn.close()

# --------------------------
# 2ï¸âƒ£ List All Admins
# --------------------------
def list_admins():
    conn = connect_db()
    if not conn:
        return
    cur = conn.cursor()

    cur.execute("SELECT username, email FROM users WHERE is_admin = 1")
    admins = cur.fetchall()

    if not admins:
        print("âš ï¸ No admins found in the system.")
    else:
        print("\nðŸ§‘â€ðŸ’¼ Current Admins:")
        for idx, a in enumerate(admins, 1):
            print(f"  {idx}. {a[0]} ({a[1]})")

    conn.close()

# --------------------------
# 3ï¸âƒ£ Remove Admin Rights
# --------------------------
def remove_admin(email):
    conn = connect_db()
    if not conn:
        return
    cur = conn.cursor()

    cur.execute("SELECT id, username, is_admin FROM users WHERE email = ?", (email,))
    user = cur.fetchone()

    if not user:
        print(f"âš ï¸ No user found with email: {email}")
    elif user[2] == 0:
        print(f"â„¹ï¸ '{email}' is not an admin.")
    else:
        cur.execute("UPDATE users SET is_admin = 0 WHERE email = ?", (email,))
        conn.commit()
        print(f"ðŸš« '{email}' admin privileges removed.")

    conn.close()

# --------------------------
# 4ï¸âƒ£ Direct Admin Promotion
# --------------------------
def main():
    # Directly promote vedantwarekar3@gmail.com to admin
    target_email = "vedantwarekar3@gmail.com"
    make_admin(target_email)
    print(f"User {target_email} successfully promoted to Admin in Ocnobloom.")

if __name__ == "__main__":
    main()

