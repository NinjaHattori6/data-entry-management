﻿# FINAL CLEAN APP.PY â€” FULLY COMPATIBLE WITH YOUR DB SCHEMA

import os
import time
import sqlite3
import random
import hashlib
from functools import wraps
from datetime import timedelta, datetime
from io import BytesIO

from dotenv import load_dotenv
from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, send_file, abort
)
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def check_sha256_password(stored_hash, provided_password):
    """Check password against SHA256 hash"""
    provided_hash = hashlib.sha256(provided_password.encode()).hexdigest()
    return provided_hash == stored_hash

# ---------------------------------------------------------
# LOGGING + EMAIL SUPPORT
# ---------------------------------------------------------

import logging
import smtplib
from email.mime.text import MIMEText

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
EMAIL_USER = os.getenv("EMAIL_USER")
EMAIL_PASS = os.getenv("EMAIL_PASS")

logging.basicConfig(
    filename="app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# ---------------------------------------------------------
# LOAD CONFIG
# ---------------------------------------------------------

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev_secret_change_me")
DB_NAME = os.getenv("DATABASE_NAME", "data_entry.db")

app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=60)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE'] = False



# ---------------------------------------------------------
# DATABASE HELPER
# ---------------------------------------------------------

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def generate_patient_id():
    """Generate unique patient ID like CP-2025-0001"""
    year = datetime.now().year
    conn = get_db_connection()
    count = conn.execute("SELECT COUNT(*) as count FROM patients WHERE patient_id LIKE ?", (f'CP-{year}-%',)).fetchone()['count']
    conn.close()
    return f'CP-{year}-{str(count + 1).zfill(4)}'

# ---------------------------------------------------------
# INITIALIZE DATABASE (MEDICAL SCHEMA)
# ---------------------------------------------------------

def init_db():
    conn = get_db_connection()

    # USERS TABLE
    conn.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0
    )
    """)

    # CANCER PATIENT MANAGEMENT TABLE
    conn.execute("""
    CREATE TABLE IF NOT EXISTS patients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        age INTEGER NOT NULL,
        gender TEXT CHECK(gender IN ('Male','Female','Other')) NOT NULL,
        cancer_type TEXT NOT NULL,
        stage TEXT CHECK(stage IN ('Stage I','Stage II','Stage III','Stage IV')) NOT NULL,
        diagnosis_date DATE NOT NULL,
        treatment_type TEXT,
        status TEXT CHECK(status IN ('Diagnosed','Under Treatment','Remission','Relapse','Deceased')) NOT NULL,
        doctor_assigned TEXT,
        contact_number TEXT,
        notes TEXT,
        created_by INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP,
        FOREIGN KEY(created_by) REFERENCES users(id)
    )
    """)

    conn.commit()
    conn.close()


# ---------------------------------------------------------
# AUTH DECORATORS
# ---------------------------------------------------------

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            flash("Admins only.", "danger")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return wrapper


# ---------------------------------------------------------
# OTP SYSTEM
# ---------------------------------------------------------

OTP_TTL = 300

def generate_and_store_otp(email):
    otp = random.randint(100000, 999999)
    session["otp"] = str(otp)
    session["otp_email"] = email
    session["otp_exp"] = time.time() + OTP_TTL
    return otp


def validate_otp(entered):
    otp = session.get("otp")
    exp = session.get("otp_exp")
    if not otp:
        return False, "No OTP found."
    if time.time() > exp:
        session.pop("otp", None)
        session.pop("otp_exp", None)
        return False, "OTP expired."
    if str(entered) != otp:
        return False, "Invalid OTP."
    session.pop("otp", None)
    session.pop("otp_exp", None)
    return True, "OTP correct."

def send_otp_email(receiver_email, otp):
    if not EMAIL_USER or not EMAIL_PASS:
        logging.error("Email credentials not configured.")
        return False

    try:
        msg = MIMEText(
            f"Your OTP for Data Vault password reset is: {otp}\n\nValid for 5 minutes."
        )
        msg["Subject"] = "Data Vault - OTP Verification"
        msg["From"] = EMAIL_USER
        msg["To"] = receiver_email

        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(EMAIL_USER, EMAIL_PASS)
        server.sendmail(EMAIL_USER, receiver_email, msg.as_string())
        server.quit()

        logging.info(f"OTP sent to {receiver_email}")
        return True

    except Exception as e:
        logging.error(f"Email error: {e}")
        return False


# ---------------------------------------------------------
# INDEX
# ---------------------------------------------------------

@app.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return render_template("index.html")


# ---------------------------------------------------------
# REGISTER
# ---------------------------------------------------------

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]

        if not username or not email or not password:
            flash("All fields required.", "warning")
            return redirect(url_for("register"))

        pwd_hash = generate_password_hash(password)

        conn = get_db_connection()
        try:
            conn.execute(
                "INSERT INTO users (username, email, password, is_admin) VALUES (?, ?, ?, ?)",
                (username, email, pwd_hash, 0)
            )
            conn.commit()
        except sqlite3.IntegrityError:
            flash("Email already registered.", "danger")
            conn.close()
            return redirect(url_for("register"))

        conn.close()
        flash("Registered successfully! Log in now.", "success")
        return redirect(url_for("login"))

    return render_template("auth/register.html")


# ---------------------------------------------------------
# LOGIN
# ---------------------------------------------------------

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]

        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()

        if not user or not check_sha256_password(user["password"], password):
            logging.warning(f"Failed login attempt: {email}")
            flash("Invalid email or password.", "danger")
            return redirect(url_for("login"))

        logging.info(f"User logged in: {email}")
        session.clear()
        session["user_id"] = user["id"]
        session["username"] = user["username"]
        session["email"] = user["email"]
        session["is_admin"] = bool(user["is_admin"])

        flash(f"Welcome, {user['username']}!", "success")
        return redirect(url_for("dashboard"))

    return render_template("auth/login.html")


# ---------------------------------------------------------
# LOGOUT
# ---------------------------------------------------------

@app.route("/logout")
def logout():
    logging.info(f"User logged out: {session.get('email')}")
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for("index"))


# ---------------------------------------------------------
# FORGOT PASSWORD (OTP)
# ---------------------------------------------------------

@app.route("/forget", methods=["GET", "POST"])
def forget():
    if request.method == "POST":
        email = request.form["email"].strip().lower()

        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()

        if not user:
            flash("Email not found.", "danger")
            return redirect(url_for("forget"))

        otp = generate_and_store_otp(email)

        if send_otp_email(email, otp):
            flash("OTP sent to your registered email.", "info")
        else:
            flash("Failed to send OTP email. Contact admin.", "danger")
            return redirect(url_for("forget"))

        return redirect(url_for("otp"))

    return render_template("auth/forget.html")


@app.route("/otp", methods=["GET", "POST"])
def otp():
    if request.method == "POST":
        entered = request.form["otp"]
        ok, msg = validate_otp(entered)

        if ok:
            session["reset_email"] = session.get("otp_email")
            flash("OTP verified.", "success")
            return redirect(url_for("reset_password"))

        flash(msg, "danger")
        return redirect(url_for("otp"))

    return render_template("auth/otp.html")


@app.route("/reset", methods=["GET", "POST"])
def reset_password():
    email = session.get("reset_email")
    if not email:
        flash("No OTP verification found.", "warning")
        return redirect(url_for("forget"))

    if request.method == "POST":
        new_pw = request.form["password"]
        hashed = generate_password_hash(new_pw)

        conn = get_db_connection()
        conn.execute("UPDATE users SET password=? WHERE email=?", (hashed, email))
        conn.commit()
        conn.close()

        session.pop("reset_email", None)
        flash("Password updated.", "success")
        return redirect(url_for("login"))

    return render_template("auth/reset.html")


# ---------------------------------------------------------
# DASHBOARD
# ---------------------------------------------------------

# ---------------------------------------------------------
# DASHBOARD (STATISTICS ONLY)
# ---------------------------------------------------------

@app.route('/dashboard')
@login_required
def dashboard():
    """Dashboard with statistics and summary charts only"""
    conn = get_db_connection()
    
    # Get base statistics for all accessible patients
    base_query = """
        SELECT p.*, u.username AS created_by_name
        FROM patients p
        JOIN users u ON p.created_by = u.id
    """
    
    conditions = []
    params = []
    
    # Restrict normal users
    if not session.get("is_admin"):
        conditions.append("p.created_by = ?")
        params.append(session["user_id"])
    
    if conditions:
        base_query += " WHERE " + " AND ".join(conditions)
    
    patients = conn.execute(base_query, params).fetchall()
    
    # Calculate statistics
    total_patients = len(patients)
    under_treatment = len([p for p in patients if p['status'] == 'Under Treatment'])
    remission = len([p for p in patients if p['status'] == 'Remission'])
    relapse = len([p for p in patients if p['status'] == 'Relapse'])
    deceased = len([p for p in patients if p['status'] == 'Deceased'])
    
    # Stage distribution
    stage_i = len([p for p in patients if p['stage'] == 'Stage I'])
    stage_ii = len([p for p in patients if p['stage'] == 'Stage II'])
    stage_iii = len([p for p in patients if p['stage'] == 'Stage III'])
    stage_iv = len([p for p in patients if p['stage'] == 'Stage IV'])
    
    # Cancer type distribution for summary chart
    cancer_types = {}
    for p in patients:
        cancer_type = p['cancer_type']
        cancer_types[cancer_type] = cancer_types.get(cancer_type, 0) + 1
    
    # Status distribution for summary chart
    status_counts = {}
    for p in patients:
        status = p['status']
        status_counts[status] = status_counts.get(status, 0) + 1
    
    conn.close()
    
    return render_template(
        'dashboard/dashboard.html',
        total_patients=total_patients,
        under_treatment=under_treatment,
        remission=remission,
        relapse=relapse,
        deceased=deceased,
        stage_i=stage_i,
        stage_ii=stage_ii,
        stage_iii=stage_iii,
        stage_iv=stage_iv,
        cancer_types=cancer_types,
        status_counts=status_counts,
        username=session.get('username')
    )

# ---------------------------------------------------------
# ADD RECORD PAGE
# ---------------------------------------------------------

@app.route('/add')
@login_required
def add_record():
    """Dedicated page for adding new records"""
    return render_template('patients/add.html', username=session.get('username'))

# ---------------------------------------------------------
# RECORDS PAGE
# ---------------------------------------------------------

@app.route('/records')
@login_required
def records():
    """Records page with search, filters, and data table"""
    conn = get_db_connection()
    
    # GET FILTER PARAMETERS
    search = request.args.get("search", "").strip()
    cancer_type = request.args.get("cancer_type", "")
    stage = request.args.get("stage", "")
    status = request.args.get("status", "")
    doctor = request.args.get("doctor", "")
    date_from = request.args.get("date_from", "")
    date_to = request.args.get("date_to", "")
    
    base_query = """
        SELECT p.*, u.username AS created_by_name
        FROM patients p
        JOIN users u ON p.created_by = u.id
    """
    
    conditions = []
    params = []
    
    # Restrict normal users
    if not session.get("is_admin"):
        conditions.append("p.created_by = ?")
        params.append(session["user_id"])
    
    # Search filters
    if search:
        conditions.append("p.full_name LIKE ?")
        params.append(f"%{search}%")
    
    if cancer_type:
        conditions.append("p.cancer_type = ?")
        params.append(cancer_type)
    
    if stage:
        conditions.append("p.stage = ?")
        params.append(stage)
    
    if status:
        conditions.append("p.status = ?")
        params.append(status)
    
    if doctor:
        conditions.append("p.doctor_assigned LIKE ?")
        params.append(f"%{doctor}%")
    
    if date_from:
        conditions.append("p.diagnosis_date >= ?")
        params.append(date_from)
    
    if date_to:
        conditions.append("p.diagnosis_date <= ?")
        params.append(date_to)
    
    if conditions:
        base_query += " WHERE " + " AND ".join(conditions)
    
    base_query += " ORDER BY p.id DESC"
    
    patients = conn.execute(base_query, params).fetchall()
    conn.close()
    
    return render_template(
        'patients/records.html',
        patients=patients,
        username=session.get('username'),
        search=search,
        cancer_type=cancer_type,
        stage=stage,
        status=status,
        doctor=doctor,
        date_from=date_from,
        date_to=date_to
    )

# ---------------------------------------------------------
# ANALYTICS PAGE
# ---------------------------------------------------------

@app.route('/analytics')
@login_required
def analytics():
    """Analytics page with all charts and detailed insights"""
    conn = get_db_connection()
    
    # Get all accessible patients for analytics
    base_query = """
        SELECT p.*, u.username AS created_by_name
        FROM patients p
        JOIN users u ON p.created_by = u.id
    """
    
    conditions = []
    params = []
    
    # Restrict normal users
    if not session.get("is_admin"):
        conditions.append("p.created_by = ?")
        params.append(session["user_id"])
    
    if conditions:
        base_query += " WHERE " + " AND ".join(conditions)
    
    base_query += " ORDER BY p.id DESC"
    
    patients = conn.execute(base_query, params).fetchall()
    
    # Calculate all analytics data
    total_patients = len(patients)
    under_treatment = len([p for p in patients if p['status'] == 'Under Treatment'])
    remission = len([p for p in patients if p['status'] == 'Remission'])
    relapse = len([p for p in patients if p['status'] == 'Relapse'])
    deceased = len([p for p in patients if p['status'] == 'Deceased'])
    
    # Stage distribution
    stage_i = len([p for p in patients if p['stage'] == 'Stage I'])
    stage_ii = len([p for p in patients if p['stage'] == 'Stage II'])
    stage_iii = len([p for p in patients if p['stage'] == 'Stage III'])
    stage_iv = len([p for p in patients if p['stage'] == 'Stage IV'])
    
    # Cancer type distribution
    cancer_types = {}
    for p in patients:
        cancer_type = p['cancer_type']
        cancer_types[cancer_type] = cancer_types.get(cancer_type, 0) + 1
    
    # Status distribution
    status_counts = {}
    for p in patients:
        status = p['status']
        status_counts[status] = status_counts.get(status, 0) + 1
    
    # Monthly trends (group by diagnosis date)
    monthly_trends = {}
    for p in patients:
        if p['diagnosis_date']:
            month_key = p['diagnosis_date'][:7]  # YYYY-MM format
            monthly_trends[month_key] = monthly_trends.get(month_key, 0) + 1
    
    conn.close()
    
    return render_template(
        'dashboard/analytics.html',
        total_patients=total_patients,
        under_treatment=under_treatment,
        remission=remission,
        relapse=relapse,
        deceased=deceased,
        stage_i=stage_i,
        stage_ii=stage_ii,
        stage_iii=stage_iii,
        stage_iv=stage_iv,
        cancer_types=cancer_types,
        status_counts=status_counts,
        monthly_trends=monthly_trends,
        username=session.get('username')
    )

# ---------------------------------------------------------
# ADD PATIENT
# ---------------------------------------------------------

@app.route('/add_patient', methods=['POST'])
@login_required
def add_patient():

    full_name = request.form['full_name'].strip()
    age = int(request.form['age'])
    gender = request.form['gender']
    cancer_type = request.form['cancer_type'].strip()
    stage = request.form['stage']
    diagnosis_date = request.form['diagnosis_date']
    treatment_type = request.form.get('treatment_type', '').strip()
    status = request.form['status']
    doctor_assigned = request.form.get('doctor_assigned', '').strip()
    contact_number = request.form.get('contact_number', '').strip()
    notes = request.form.get('notes', '').strip()

    # Validation
    if not full_name:
        flash("Full name is required.", "danger")
        return redirect(url_for('dashboard'))

    if age < 0 or age > 120:
        flash("Invalid age value.", "danger")
        return redirect(url_for('dashboard'))

    conn = get_db_connection()
    patient_id = generate_patient_id()

    try:
        conn.execute("""
            INSERT INTO patients (
                patient_id, full_name, age, gender, cancer_type, stage,
                diagnosis_date, treatment_type, status, doctor_assigned,
                contact_number, notes, created_by, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            patient_id, full_name, age, gender, cancer_type, stage,
            diagnosis_date, treatment_type, status, doctor_assigned,
            contact_number, notes, session['user_id'], datetime.now()
        ))

        conn.commit()
        flash("Patient added successfully!", "success")

    except sqlite3.Error as e:
        flash(f"Database error: {e}", "danger")

    finally:
        conn.close()

    return redirect(url_for('dashboard'))

# ---------------------------------------------------------
# VIEW PATIENT
# ---------------------------------------------------------

@app.route("/view_patient/<int:patient_id>")
@login_required
def view_patient(patient_id):
    conn = get_db_connection()

    if session.get("is_admin"):
        patient = conn.execute(
            "SELECT p.*, u.username AS created_by_name FROM patients p JOIN users u ON p.created_by = u.id WHERE p.id=?",
            (patient_id,)
        ).fetchone()
    else:
        patient = conn.execute(
            "SELECT * FROM patients WHERE id=? AND created_by=?",
            (patient_id, session["user_id"])
        ).fetchone()

    conn.close()

    if not patient:
        flash("Patient not found.", "danger")
        return redirect(url_for("dashboard"))

    return render_template("patients/view_patient.html", patient=patient)


# ---------------------------------------------------------
# EDIT PATIENT
# ---------------------------------------------------------

@app.route("/edit_patient/<int:patient_id>", methods=["GET", "POST"])
@login_required
def edit_patient(patient_id):

    conn = get_db_connection()

    if session.get("is_admin"):
        patient = conn.execute(
            "SELECT p.*, u.username AS created_by_name FROM patients p JOIN users u ON p.created_by = u.id WHERE p.id=?",
            (patient_id,)
        ).fetchone()
    else:
        patient = conn.execute(
            "SELECT * FROM patients WHERE id=? AND created_by=?",
            (patient_id, session["user_id"])
        ).fetchone()

    if not patient:
        conn.close()
        flash("Patient not found.", "danger")
        return redirect(url_for("dashboard"))

    if request.method == "POST":

        full_name = request.form["full_name"].strip()
        age = int(request.form["age"])
        gender = request.form["gender"]
        cancer_type = request.form["cancer_type"].strip()
        stage = request.form["stage"]
        diagnosis_date = request.form["diagnosis_date"]
        treatment_type = request.form.get("treatment_type", "").strip()
        status = request.form["status"]
        doctor_assigned = request.form.get("doctor_assigned", "").strip()
        contact_number = request.form.get("contact_number", "").strip()
        notes = request.form.get("notes", "").strip()

        if not full_name:
            flash("Full name is required.", "danger")
            return redirect(url_for("edit_patient", patient_id=patient_id))

        if age < 0 or age > 120:
            flash("Invalid age value.", "danger")
            return redirect(url_for("edit_patient", patient_id=patient_id))

        try:
            conn.execute("""
                UPDATE patients SET 
                    full_name=?, age=?, gender=?, cancer_type=?, stage=?,
                    diagnosis_date=?, treatment_type=?, status=?, doctor_assigned=?,
                    contact_number=?, notes=?, updated_at=?
                WHERE id=?
            """, (
                full_name, age, gender, cancer_type, stage,
                diagnosis_date, treatment_type, status, doctor_assigned,
                contact_number, notes, datetime.now(), patient_id
            ))

            conn.commit()
            flash("Patient updated successfully!", "success")

        except sqlite3.Error as e:
            flash(f"Database error: {e}", "danger")

        finally:
            conn.close()

        return redirect(url_for("dashboard"))

    conn.close()
    return render_template("patients/edit_patient.html", patient=patient)


# ---------------------------------------------------------
# DELETE PATIENT (SOFT DELETE)
# ---------------------------------------------------------

@app.route("/delete_patient/<int:patient_id>")
@login_required
def delete_patient(patient_id):
    conn = get_db_connection()

    if session.get("is_admin"):
        conn.execute("UPDATE patients SET status='Deceased', updated_at=? WHERE id=?", 
                   (datetime.now(), patient_id))
    else:
        conn.execute("UPDATE patients SET status='Deceased', updated_at=? WHERE id=? AND created_by=?", 
                   (datetime.now(), patient_id, session["user_id"]))

    conn.commit()
    conn.close()

    flash("Patient record marked as deceased.", "info")
    return redirect(url_for("dashboard"))


# ---------------------------------------------------------
# PROFILE
# ---------------------------------------------------------

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()

    if request.method == "POST":
        old = request.form["old_password"]
        new = request.form["new_password"]
        confirm = request.form["confirm_password"]

        if not check_password_hash(user["password"], old):
            flash("Old password incorrect.", "danger")
            conn.close()
            return redirect(url_for("profile"))

        if new != confirm:
            flash("Passwords do not match.", "warning")
            conn.close()
            return redirect(url_for("profile"))

        new_hash = generate_password_hash(new)
        conn.execute("UPDATE users SET password=? WHERE id=?", (new_hash, session["user_id"]))
        conn.commit()
        conn.close()

        flash("Password updated!", "success")
        return redirect(url_for("profile"))

    conn.close()
    return render_template("user/profile.html", user=user)


# ---------------------------------------------------------
# ADMIN: USERS LIST
# ---------------------------------------------------------

@app.route("/admin")
@admin_required
def admin():
    conn = get_db_connection()
    users = conn.execute("SELECT id, username, email, is_admin FROM users ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("admin/admin.html", users=users)


@app.route("/admin/promote/<int:user_id>", methods=["POST"])
@admin_required
def admin_promote(user_id):
    conn = get_db_connection()
    conn.execute("UPDATE users SET is_admin=1 WHERE id=?", (user_id,))
    conn.commit()
    conn.close()
    flash("User promoted!", "success")
    return redirect(url_for("admin"))


@app.route("/admin/demote/<int:user_id>", methods=["POST"])
@admin_required
def admin_demote(user_id):
    if session["user_id"] == user_id:
        flash("You cannot demote yourself.", "warning")
        return redirect(url_for("admin"))

    conn = get_db_connection()
    conn.execute("UPDATE users SET is_admin=0 WHERE id=?", (user_id,))
    conn.commit()
    conn.close()
    flash("User demoted.", "info")
    return redirect(url_for("admin"))


@app.route("/admin/delete_user/<int:user_id>", methods=["POST"])
@admin_required
def admin_delete_user(user_id):
    if session["user_id"] == user_id:
        flash("You cannot delete your own account.", "warning")
        return redirect(url_for("admin"))

    conn = get_db_connection()
    conn.execute("DELETE FROM entries WHERE user_id=?", (user_id,))
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()

    flash("User deleted.", "info")
    return redirect(url_for("admin"))


# ---------------------------------------------------------
# ---------------------------------------------------------
# EXPORT DATA
# ---------------------------------------------------------

@app.route("/export/<string:fmt>")
@login_required
def export(fmt):

    conn = get_db_connection()

    if session.get("is_admin"):
        rows = conn.execute("""
            SELECT 
                p.patient_id,
                p.full_name,
                p.age,
                p.gender,
                p.cancer_type,
                p.stage,
                p.diagnosis_date,
                p.treatment_type,
                p.status,
                p.doctor_assigned,
                p.contact_number,
                p.notes,
                p.created_at,
                u.username AS created_by_name
            FROM patients p
            JOIN users u ON p.created_by = u.id
            ORDER BY p.id DESC
        """).fetchall()
    else:
        rows = conn.execute("""
            SELECT 
                patient_id,
                full_name,
                age,
                gender,
                cancer_type,
                stage,
                diagnosis_date,
                treatment_type,
                status,
                doctor_assigned,
                contact_number,
                notes,
                created_at
            FROM patients
            WHERE created_by=?
            ORDER BY id DESC
        """, (session["user_id"],)).fetchall()

    conn.close()

    if not rows:
        flash("No patient data available for export.", "warning")
        return redirect(url_for("dashboard"))

    df = pd.DataFrame([dict(r) for r in rows])

    now_str = datetime.now().strftime("%Y%m%d_%H%M%S")

    # CSV
    if fmt == "csv":
        buf = BytesIO()
        df.to_csv(buf, index=False)
        buf.seek(0)
        return send_file(buf, as_attachment=True,
                         download_name=f"patients_{now_str}.csv")

    # Excel
    if fmt == "xlsx":
        buf = BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Patients")
        buf.seek(0)
        return send_file(buf, as_attachment=True,
                         download_name=f"patients_{now_str}.xlsx")

    # PDF
    if fmt == "pdf":
        buf = BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=letter)
        elements = []

        # Title
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            spaceAfter=30,
            alignment=1  # Center
        )
        elements.append(Paragraph("Cancer Patient Management Report", title_style))

        # Table data
        data = [df.columns.tolist()] + df.values.tolist()

        table = Table(data, repeatRows=1)

        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('ALIGN', (2, 1), (2, -1), 'CENTER')
        ]))

        elements.append(table)
        doc.build(elements)

        buf.seek(0)
        return send_file(buf, as_attachment=True,
                         download_name=f"patients_{now_str}.pdf")

    abort(400)


# ---------------------------------------------------------
# EXPORT EXCEL
# ---------------------------------------------------------

@app.route("/export_excel")
@login_required
def export_excel():
    return export("xlsx")


# ---------------------------------------------------------
# EXPORT PDF
# ---------------------------------------------------------

@app.route("/export_pdf")
@login_required
def export_pdf():
    return export("pdf")


# ---------------------------------------------------------
# HEALTH CHECK
# ---------------------------------------------------------

@app.route("/health")
def health():
    try:
        conn = get_db_connection()
        conn.execute("SELECT 1")
        conn.close()
        return "OK"
    except Exception as e:
        return f"ERR: {e}"


# ---------------------------------------------------------
# RUN SERVER
# ---------------------------------------------------------

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
