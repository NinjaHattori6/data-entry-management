#!/usr/bin/env python3
"""
Generate 50 realistic patient records for Ocnobloom testing
"""

import sqlite3
import random
from datetime import datetime, timedelta
from faker import Faker

# Initialize Faker with Indian locale
fake = Faker('en_IN')

# Indian names database
INDIAN_NAMES = {
    'male': [
        'Rajesh Kumar', 'Amit Sharma', 'Vikram Singh', 'Sanjay Patel', 'Mohan Reddy',
        'Anand Joshi', 'Prakash Gupta', 'Ravi Verma', 'Suresh Kumar', 'Deepak Singh',
        'Arvind Kumar', 'Ashok Sharma', 'Manoj Patel', 'Nitin Gupta', 'Vijay Kumar',
        'Rahul Sharma', 'Pankaj Singh', 'Ajay Kumar', 'Sunil Patel', 'Mukesh Kumar'
    ],
    'female': [
        'Priya Sharma', 'Anita Singh', 'Pooja Patel', 'Sunita Reddy', 'Meera Joshi',
        'Kavita Gupta', 'Rekha Verma', 'Savita Kumar', 'Archana Sharma',
        'Neha Singh', 'Divya Patel', 'Swati Gupta', 'Rashmi Kumar', 'Kiran Sharma',
        'Geeta Singh', 'Madhuri Patel', 'Lata Gupta', 'Anjali Kumar', 'Poonam Sharma'
    ]
}

# Indian addresses
INDIAN_ADDRESSES = [
    '123, MG Road, Delhi - 110001', '456, Park Street, Mumbai - 400001',
    '789, Gandhi Nagar, Bangalore - 560001', '321, Nehru Place, Chennai - 600001',
    '654, Civil Lines, Kolkata - 700001', '987, Anna Salai, Hyderabad - 500001',
    '147, FC Road, Pune - 411001', '258, Brigade Road, Jaipur - 302001',
    '369, Connaught Place, New Delhi - 110001', '741, Camac Street, Bhubaneswar - 751001'
]

# Indian talukas
INDIAN_TALUKAS = [
    'Gurgaon', 'Noida', 'Thane', 'Kalyan', 'Dombivali', 'Vasai-Virar',
    'Faridabad', 'Ghaziabad', 'Meerut', 'Bulandshahr', 'Aligarh', 'Mathura',
    'Agra', 'Firozabad', 'Mainpuri', 'Etawah', 'Kanpur', 'Lucknow', 'Barabanki'
]

# Medical data
PRIMARY_SITES = [
    'Breast', 'Lung', 'Oral', 'Cervix', 'Prostate', 'Blood', 'Colon',
    'Liver', 'Stomach', 'Brain', 'Pancreas', 'Kidney', 'Bladder', 'Thyroid'
]

HISTOLOGY_TYPES = [
    'Adenocarcinoma', 'Squamous Cell Carcinoma', 'Lymphoma', 'Sarcoma', 'Carcinoma',
    'Melanoma', 'Neuroendocrine Tumor', 'Germ Cell Tumor', 'Mesothelioma'
]

TREATMENT_TYPES = [
    'Chemotherapy', 'Radiotherapy', 'Surgery', 'Immunotherapy', 'Targeted Therapy',
    'Hormone Therapy', 'Stem Cell Transplant', 'Palliative Care'
]

def generate_patient_data():
    """Generate realistic patient data"""
    
    # Generate unique patient ID
    year = datetime.now().year
    patient_count = random.randint(1, 9999)
    form_no = f'OB-{year}-{str(patient_count).zfill(4)}'
    
    # Select gender and corresponding name
    gender = random.choice(['Male', 'Female'])
    if gender == 'Male':
        name = random.choice(INDIAN_NAMES['male'])
    else:
        name = random.choice(INDIAN_NAMES['female'])
    
    # Generate age (18-85)
    age = random.randint(18, 85)
    
    # Generate phone number (10-digit Indian format)
    phone = f'+91 {random.randint(6000000000, 9999999999)}'
    
    # Select address and taluka
    address = random.choice(INDIAN_ADDRESSES)
    taluka = random.choice(INDIAN_TALUKAS)
    
    # Medical data
    primary_site = random.choice(PRIMARY_SITES)
    histology = random.choice(HISTOLOGY_TYPES)
    diagnosis_basis = random.choice(['Biopsy', 'FNAC', 'Clinical', 'Imaging', 'Histopathology'])
    
    # Status distribution with majority "Under Treatment"
    status_weights = {
        'Diagnosed': 15,
        'Under Treatment': 45,  # Majority
        'Remission': 20,
        'Relapse': 10,
        'Deceased': 10
    }
    status = random.choices(
        list(status_weights.keys()),
        weights=list(status_weights.values()),
        k=1
    )[0]
    
    # Treatment based on status
    if status in ['Under Treatment', 'Remission']:
        treatment = random.choice(TREATMENT_TYPES)
    else:
        treatment = ''
    
    # Random date within last 2 years
    days_ago = random.randint(0, 730)
    created_at = datetime.now() - timedelta(days=days_ago)
    
    return {
        'patient_id': form_no,
        'full_name': name,
        'age': age,
        'gender': gender,
        'cancer_type': primary_site,
        'stage': random.choice(['Stage I', 'Stage II', 'Stage III', 'Stage IV']),
        'diagnosis_date': created_at.strftime('%Y-%m-%d'),
        'treatment_type': treatment,
        'status': status,
        'doctor_assigned': f'Dr. {fake.last_name()}',
        'contact_number': phone,
        'notes': f'Patient presents with {primary_site} carcinoma.',
        'created_by': 1,  # Assign to existing user
        'created_at': created_at.strftime('%Y-%m-%d %H:%M:%S')
    }

def insert_test_data():
    """Insert 50 patient records into database"""
    
    # Connect to database
    conn = sqlite3.connect('registry.db')
    cursor = conn.cursor()
    
    print("🏥 Generating 50 realistic patient records for Ocnobloom...")
    
    # Generate and insert records
    for i in range(50):
        patient_data = generate_patient_data()
        
        # Insert into database
        cursor.execute("""
            INSERT INTO patients (
                patient_id, full_name, age, gender, cancer_type, stage,
                diagnosis_date, treatment_type, status, doctor_assigned,
                contact_number, notes, created_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            patient_data['patient_id'],
            patient_data['full_name'],
            patient_data['age'],
            patient_data['gender'],
            patient_data['cancer_type'],
            patient_data['stage'],
            patient_data['diagnosis_date'],
            patient_data['treatment_type'],
            patient_data['status'],
            patient_data['doctor_assigned'],
            patient_data['contact_number'],
            patient_data['notes'],
            patient_data['created_by'],
            patient_data['created_at'],
            patient_data['created_at']  # Use created_at for updated_at as well
        ))
        
        print(f"  ✅ Generated: {patient_data['full_name']} ({patient_data['patient_id']}) - {patient_data['status']}")
    
    # Commit and close
    conn.commit()
    conn.close()
    
    print("\n📊 Data Distribution Summary:")
    print("   Total Records: 50")
    print("   Gender Distribution: ~50% Male, ~50% Female")
    print("   Age Range: 18-85 years")
    print("   Primary Sites: Mixed (Breast, Lung, Oral, etc.)")
    print("   Status Distribution: 45% Under Treatment, 20% Remission, 15% Diagnosed")
    print("   Geographic: Indian addresses and names")
    print("   Phone Format: +91 XXXXXXXXXX")
    print("   Date Range: Last 2 years")
    
    print("\n🎯 50 test patient records successfully inserted into Ocnobloom database!")

if __name__ == "__main__":
    install_required = input("Do you want to install Faker library? (y/n): ").lower()
    if install_required == 'y':
        import subprocess
        import sys
        subprocess.check_call([sys.executable, "-m", "pip", "install", "faker"])
        print("✅ Faker library installed successfully!")
    
    try:
        from faker import Faker
        insert_test_data()
    except ImportError:
        print("❌ Error: Faker library not installed.")
        print("Please run: pip install faker")
        print("Or install it manually and run this script again.")
