import sqlite3

# Connect to database
conn = sqlite3.connect('data_entry.db')
cursor = conn.cursor()

# Query users table
cursor.execute('SELECT id, username, email, is_admin FROM users ORDER BY id')
users = cursor.fetchall()

print('🔍 USER ACCOUNTS IN DATABASE:')
print('=' * 40)

for user in users:
    user_id, username, email, is_admin = user
    print(f'ID: {user_id}')
    print(f'Username: {username}')
    print(f'Email: {email}')
    print(f'Admin: {"Yes" if is_admin else "No"}')
    print('-' * 30)

conn.close()

print('\n🎯 LOGIN CREDENTIALS:')
print('You can use any of these accounts to login:')
