import sqlite3
import hashlib

def hash_password(password):
    """Hash password using the same method as in app.py"""
    return hashlib.sha256(password.encode()).hexdigest()

# Connect to database
conn = sqlite3.connect('data_entry.db')
cursor = conn.cursor()

# Get user vedantwarekar3@gmail.com
cursor.execute('SELECT id, username, password FROM users WHERE email = ?', ('vedantwarekar3@gmail.com',))
user = cursor.fetchone()

if user:
    user_id, username, current_hash = user
    print(f'Current user: {username}')
    print(f'Current hash: {current_hash}')
    
    # New password
    new_password = 'admin123'  # You can change this
    new_hash = hash_password(new_password)
    
    print(f'\\nNew password: {new_password}')
    print(f'New hash: {new_hash}')
    
    # Update password
    cursor.execute('UPDATE users SET password = ? WHERE id = ?', (new_hash, user_id))
    conn.commit()
    
    print(f'\\n✅ Password updated for {username}')
    print(f'You can now login with:')
    print(f'  Username: {username}')
    print(f'  Password: {new_password}')
    
else:
    print('❌ User vedantwarekar3@gmail.com not found')

conn.close()
